interface BasketItem {
    id: number;

    name: string;
    description: string;
    price: number;
    quantity: number;
}
export default BasketItem;
