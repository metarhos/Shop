enum ErrorTypes {
    AUTH_ERROR, NETWORK_ERROR, SERVER_ERROR
}
export default ErrorTypes;
