interface EmployeeBase {
    id: number;
    name: string;

    department: string;
    salary: number;
    education?: string
}
export default EmployeeBase;
