interface BasketItem {
    //barcode: number;
    id: string;
    products: Map<string, any>[]

    // name: string;
    // description: string;
    // price: number;
    // quantity: number;
}
export default BasketItem;
