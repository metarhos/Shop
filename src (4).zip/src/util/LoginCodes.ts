enum LoginCodes {
    OK,WRONG_CREDENTIALS,NETWORK_ERROR
}
export default LoginCodes;
