import React, {useRef, useState} from 'react'
import {headersAll, headersWidth} from "../../config/basket-table-config";
import Topbar from "../library/Topbar";
import DeleteIcon from '@material-ui/icons/Delete';
import {Backdrop, Fade, Modal, Theme} from "@material-ui/core";
import {makeStyles} from "@material-ui/core/styles";
import {getDropMenuItems, getMenuItems, getNumberTabs} from "./Home";
import {useSelector} from "react-redux";
import {ReducersType} from "../../store/store";
import {UserData} from "../../services/AuthService";
import ErrorTypes from "../../util/ErrorTypes";
import AddCircleIcon from '@material-ui/icons/AddCircle';
import {HeaderDescription, MyTable} from "../library/MyTable";
import EditIcon from '@material-ui/icons/Edit';
import ConfirmationDialog from "../library/ConfirmDialog";
import EmployeeForm from "../EmployeeForm";
import EmployeeView from "../../models/EmployeeView";
import Employee from "../../models/EmployeeType";
import {serviceBasket} from "../../config/server-config";
import BasketItem from "../../models/BasketItem";
import RemoveCircleIcon from '@material-ui/icons/RemoveCircle';
type Props = {
    refreshFn?: () => void;

}


const useStyles = makeStyles((theme: Theme) =>
//можно маргинТоп: тема.спэйсинг(20пх) тогда например заложит для всей темы. Ихменение глобальных компонентов
// Тему можно поменять. В апп положить тема: Тема = креатеМуиТема и т.д.
    ({
        modal: {
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',

        },
        paper: {
            backgroundColor: theme.palette.background.paper,
            // border: '2px solid #000',
            boxShadow: theme.shadows[5],
            padding: theme.spacing(2, 4, 3),
        },

    }));

export function getHeaders(width: number, isAdmin: boolean): Map<string, HeaderDescription> {
//Complite
    const headersWidthArray = headersWidth;
     const index = headersWidthArray.findIndex(hw => width > hw[0] );
     return headersWidthArray[index][1];
}


export const Basket: React.FC<Props> = (props: Props) => {
    const classes = useStyles()
    const width: number = useSelector((state: ReducersType) => state.width);
    const userData: UserData = useSelector((state: ReducersType) => state.userData);
    const baskets: BasketItem[] = useSelector((state: ReducersType) => state.baskets);

    const [open, setOpen] = useState<boolean>(false);
    const [modal, setModal] = useState<{open:boolean,
        basket:BasketItem|undefined}>({open:false,
        basket: undefined});
    const idRef = useRef<number>(0);
    const headers: Map<string, HeaderDescription> = getHeaders(width, userData.isAdmin);

    function removeBasket(baskObj: object) {
        idRef.current = (baskObj as BasketItem).id //this casting because this is actionFn(obj: Object)
        //Таблица принимает обжект, так что надо конвертировать так как мы юзаем эмплоя.
        //Тоесть любой объект надо конвертировать в зависимости от родителя. Таблица же универсальная и принимает тока обжект.
        //get id in MyTable in getActionButtons
        setOpen(true)
        debugger
    }
    async function addProduct(baskObj: object) {
        idRef.current = (baskObj as BasketItem).id
        await serviceBasket.addBasketItem(idRef.current,baskObj as BasketItem);
        !!props.refreshFn && props.refreshFn()
     debugger
    }

    async function removeProduct(baskObj: object) {
        idRef.current = (baskObj as BasketItem).id
        await serviceBasket.removeOneBasketItem(idRef.current,baskObj as BasketItem);
        !!props.refreshFn && props.refreshFn()
        debugger
    }


    async function onClose(res: boolean) { //res get from click in alertDialog
        setOpen(false);
        if (res) {
            try {
                await serviceBasket.removeBasketItem(idRef.current);
                !!props.refreshFn && props.refreshFn()
            } catch(error) {
                const errorEnum: ErrorTypes = error as ErrorTypes;
                const alertMessage = errorEnum === ErrorTypes.SERVER_ERROR ?
                    `Product with id ${idRef.current} doesn't exist` :
                    ( errorEnum === ErrorTypes.NETWORK_ERROR ?
                        'Server is not available, please repeat later' : 'Auth Error');
                alert(alertMessage);
            }
            //!! конвретирует наличие метода в булеан, тоесть тру или фолс. !! значит тру. Если существует, то делай
        }
    }
    function handleModalClose() {
        modal.open = false;
        setModal({...modal});
    }

    return <React.Fragment>
        <Topbar dropMenu={getDropMenuItems(userData)} menu={getMenuItems(userData)} countNavigator={getNumberTabs(width)}/>
        <MyTable defaultRowsPerPage={width > 500 && width < 900 ? 5 : 10}
                 innerWidth={width < 700? width : undefined} isDetails={headers !== headersAll}
                 headers={headers} rows={baskets}
                 actions={[
                     {icon: <AddCircleIcon/>, actionFn: addProduct},
                     {icon: <RemoveCircleIcon/>, actionFn: removeProduct},
                     {icon: <DeleteIcon/>, actionFn: removeBasket}
                     ]}/>
        <ConfirmationDialog title={'You are going remove'} open={open}
                            content={`product with id ${idRef.current}`} onClose={onClose}/>

    </React.Fragment>
}
export default Basket;