import {Observable} from "rxjs";
import BasketItem from "../models/BasketItem";

export default interface BasketItemServiceObservable {
    addBasketItem(id: number, basket: BasketItem):Promise<any>;
    removeBasketItem(id: number): Promise<any>;
    getAllBasketItem(): Observable<BasketItem[]>;
    updateBasketItem(id: number, basket: BasketItem): Promise<any>;
    removeOneBasketItem(id: number, basket: BasketItem):Promise<any>;
}
