import firebase from "firebase";
import appFirebase from "../config/firebase-sdk";
import {collectionData, docData} from "rxfire/firestore";

import {Observable, of} from "rxjs";
import ErrorTypes from "../util/ErrorTypes";


import {map, mergeMap} from "rxjs/operators";
import BasketItemServiceObservable from "./BasketItemServiceObservable";
import BasketItem from "../models/BasketItem";
import {UserData} from "./AuthService";
import {serviceBasket} from "../config/server-config";
import {useDispatch} from "react-redux";
import {basketsItemAction} from "../store/actions";


export default class BasketItemServiceFirebase implements BasketItemServiceObservable {

    db: firebase.firestore.CollectionReference<firebase.firestore.DocumentData>;


    constructor(collection: string) {
        this.db = appFirebase.firestore().collection(collection);
        this.collection = collection
    }


    exists(id: any): Promise<boolean> {
        debugger
        let a = this.db.doc(id.toString()).get().then(doc => doc.exists);
        debugger
        return a
    }


    async removeBasketItem(id: number): Promise<any> {
        if (await this.exists(id)) {
            return this.db.doc(id.toString()).delete();
        }
        throw ErrorTypes.SERVER_ERROR;
    }

    async updateBasketItem(id: number, basket: BasketItem): Promise<any> {
        if (await this.exists(id)) {
            const baskFire: BasketItem = basket;
            return this.db.doc(basket.id.toString()).set(baskFire)
        }
        throw ErrorTypes.SERVER_ERROR;
    }


    getBasket(userData: UserData): Observable<BasketItem> {
        // let a = docData(this.db.doc(userData.uid))
        debugger
        return docData(this.db.doc(userData.uid))


        // const query = this.db.where('id', '==', userData.uid);
        //for work this need add index in firestore for cllction and id
    }


    async addBasketItem(basket: BasketItem): Promise<any> {

        debugger
        // roman
        let coll = this.db
        let id = basket.id.toString()
        let res = await this.db.doc(id).set(basket)


        let res2 = await this.db.doc(id)
            .set({a: 2, id: 'sfs'})
        //
        // res2
        //     .then(el=>console.log(el))
        //     .catch(er=>console.log(er))

        // что воз-т коллекция какой тип
        const tem = await appFirebase.firestore().collection(this.collection);


        debugger
        //
        // const doc = await tem.get();
        // if (!doc.exists) {
        //     console.log('No such document!');
        // } else {
        //     console.log('Document data:', doc.data());
        // }

        console.log(tem)
        //
        debugger


        return this.db.doc(basket.id.toString()).set(basket)
    }


    async removeOneBasketItem(id: number, basket: BasketItem): Promise<any> {

        // if (await this.exists(id)) {
        //     debugger
        //     if (basket.quantity == 1) {
        //         return this.db.doc(id.toString()).delete();
        //     }
        //     const bas = {...basket, quantity: (basket.quantity - 1)}
        //     return this.db.doc(basket.id.toString()).set(bas)
        // }
        return this.db.doc(basket.id.toString()).set(basket)
    }


}
