import firebase from "firebase";
import appFirebase from "../config/firebase-sdk";
import {collectionData} from "rxfire/firestore";

import {Observable} from "rxjs";
import ErrorTypes from "../util/ErrorTypes";


import {map} from "rxjs/operators";
import BasketItemServiceObservable from "./BasketItemServiceObservable";
import BasketItem from "../models/BasketItem";
import EmployeeView from "../models/EmployeeView";
import Employee from "../models/EmployeeType";




export default class BasketItemServiceFirebase implements BasketItemServiceObservable {
     db: firebase.firestore.CollectionReference<firebase.firestore.DocumentData>;
     constructor(collection: string) {
         this.db = appFirebase.firestore().collection(collection);
     }
    exists(id: number) : Promise<boolean> {
        return this.db.doc(id.toString()).get().then(doc => doc.exists);
    }

    async removeBasketItem(id: number): Promise<any> {
        if (await this.exists(id)) {
            return this.db.doc(id.toString()).delete();
        }
        throw ErrorTypes.SERVER_ERROR;
    }

    async updateBasketItem(id: number, basket: BasketItem): Promise<any> {
        if (await this.exists(id)) {
            const baskFire: BasketItem = basket;
            return this.db.doc(basket.id.toString()).set(baskFire)
        }
        throw ErrorTypes.SERVER_ERROR;
    }



    getAllBasketItem(): Observable<BasketItem[]> {
        let a =
             collectionData<BasketItem>(this.db)
                .pipe(map((baskets) => {

                     return baskets;
                }));

            return a;
    }
    // function toOddBasket(basket: BasketItem): BasketItem {
    //     return {...basket, quantity: (basket.quantity + 1) };
    // }
    // function toEmployeeFire(empl: Employee): EmployeeView {
    //     return {...empl, birthDate: (empl.birthDate as Date).toISOString().substr(0, 10) };
    // }

    async addBasketItem(id: number, basket: BasketItem): Promise<any> {

        if (await this.exists(id)) {
            debugger
            const bas = {...basket, quantity: (basket.quantity + 1) }

            return this.db.doc(basket.id.toString()).set(bas)
        }
        return this.db.doc(basket.id.toString()).set(basket)
    }

    async removeOneBasketItem(id: number, basket: BasketItem): Promise<any> {

        if (await this.exists(id)) {
            debugger
            if(basket.quantity == 1 ){
                return this.db.doc(id.toString()).delete();
            }
            const bas = {...basket, quantity: (basket.quantity - 1) }
            return this.db.doc(basket.id.toString()).set(bas)
        }
        return this.db.doc(basket.id.toString()).set(basket)
    }



}
