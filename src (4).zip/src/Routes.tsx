import React from "react";
// import {HashRouter, Switch, Route, Redirect} from "react-router-dom";
// //import Topbar from "./components_back/Topbar";
// import {MENU} from "./config_back/Menu";
//
//
// export const Routes = () => {
//    // console.log(MENU)
//     return <React.Fragment>
//         <HashRouter>
//             <Redirect to={MENU[0].path}></Redirect>
//
//             {/*<Topbar/>*/}
//             <Switch>
//                 {MENU.map(item =>
//                     <Route key={item.label} path={item.path} exact component={item.component}/>
//                 )}
//             </Switch>
//         </HashRouter>
//     </React.Fragment>
// }