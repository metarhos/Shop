import EmployeeBase from "./EmployeeBase";


export default interface EmployeeView extends EmployeeBase {
    birthDate: string;
}
