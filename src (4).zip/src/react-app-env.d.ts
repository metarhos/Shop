/// <reference types="react-scripts" />
declare module 'react-redux';
